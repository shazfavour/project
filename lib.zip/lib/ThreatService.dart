import 'package:flutter/material.dart';

import 'main.dart';

class ThreatService {
  List<Threat> getRecentThreats() {
    return [
      Threat(
        id: '1',
        title: 'Card Skimming Attack',
        description: 'Detected card skimming malware on merchant POS',
        timestamp: '10 min ago',
        severity: 'High',
        paymentType: 'Card',
        icon: Icons.credit_card,
      ),
      Threat(
        id: '2',
        title: 'Phishing Campaign',
        description: 'Targeted phishing attacks impersonating mobile payment app',
        timestamp: '45 min ago',
        severity: 'Critical',
        paymentType: 'Mobile',
        icon: Icons.phone_android,
      ),
      Threat(
        id: '3',
        title: 'Crypto Exchange Vulnerability',
        description: 'API vulnerability allowing unauthorized transactions',
        timestamp: '2 hours ago',
        severity: 'Medium',
        paymentType: 'Crypto',
        icon: Icons.currency_bitcoin,
      ),
      Threat(
        id: '4',
        title: 'Man-in-the-Middle Attack',
        description: 'Suspicious DNS redirects for payment gateway',
        timestamp: '3 hours ago',
        severity: 'High',
        paymentType: 'E-Pay',
        icon: Icons.language,
      ),
    ];
  }

  List<Map<String, dynamic>> getThreatMetrics() {
    return [
      {
        'title': 'Active Threats',
        'value': 18,
        'change': 3,
        'icon': Icons.security_update_warning,
        'color': const Color(0xFFEA4335),
      },
      {
        'title': 'Mitigated',
        'value': 42,
        'change': -5,
        'icon': Icons.verified_user_outlined,
        'color': const Color(0xFF34A853),
      }, 
      {
        'title': 'Vulnerabilities',
        'value': 24,
        'change': 2,
        'icon': Icons.gpp_maybe_outlined,
        'color': const Color(0xFFFBBC05),
      },
      {
        'title': 'Risk Score',
        'value': 63,
        'change': -2,
        'icon': Icons.speed_outlined,
        'color': const Color(0xFF4285F4),
      },
    ];
  }

  List<Map<String, dynamic>> getSecurityBreakdownData() {
    return [
      {'type': 'Card', 'threats': 32, 'color': const Color(0xFF4285F4)},
      {'type': 'Mobile', 'threats': 24, 'color': const Color(0xFF34A853)},
      {'type': 'Crypto', 'threats': 18, 'color': const Color(0xFFF66D00)},
      {'type': 'E-Pay', 'threats': 26, 'color': const Color(0xFF9334E6)},
    ];
  }
}