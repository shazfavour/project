import 'package:flutter/material.dart';
import 'main.dart';
 

class ThreatDetailScreen extends StatelessWidget {
  final Threat threat;

  const ThreatDetailScreen({super.key, required this.threat});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(threat.title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text(
              threat.title,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 12),
            Text(
              "Severity: ${threat.severity}",
              style: TextStyle(
                color: Threat.getSeverityColor(threat.severity),
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "Payment Type: ${threat.paymentType}",
              style: TextStyle(
                color: Threat.getPaymentTypeColor(threat.paymentType),
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "Timestamp: ${threat.timestamp}",
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            Text(
              "Description:",
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Text(threat.getDetailedDescription()),
            const SizedBox(height: 24),
            Text(
              "Recommended Actions:",
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            ...threat.getRecommendedActions().map(
              (action) => ListTile(
                leading: const Icon(Icons.check_circle, color: Colors.green),
                title: Text(action),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
