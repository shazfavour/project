import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sheldpay'),
      ),
      body: const Center(
        child: Text(
          'protect your payment',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
