import 'package:flutter/material.dart';
import 'main.dart';


class PaymentService {
  List<Transaction> getRecentTransactions() {
    return [
      Transaction(
        id: 'tx1',
        amount: 125.50,
        paymentMethod: 'Credit Card',
        timestamp: '2023-03-15 14:30:25',
        status: 'Completed',
        userId: 'user1',
        riskScore: 12.5,
      ),
      Transaction(
        id: 'tx2',
        amount: 50.00,
        paymentMethod: 'Mobile Payment',
        timestamp: '2023-03-15 12:15:42',
        status: 'Completed',
        userId: 'user2',
        riskScore: 8.2,
      ),
      Transaction(
        id: 'tx3',
        amount: 1250.00,
        paymentMethod: 'Cryptocurrency',
        timestamp: '2023-03-15 10:05:17',
        status: 'Pending',
        userId: 'user3',
        riskScore: 45.8,
      ),
      Transaction(
        id: 'tx4',
        amount: 75.25,
        paymentMethod: 'E-Pay',
        timestamp: '2023-03-14 23:42:11',
        status: 'Completed',
        userId: 'user4',
        riskScore: 15.3,
      ),
    ];
  }
}

// lib/widgets/threat_indicator.dart
class ThreatIndicator extends StatelessWidget {
  final Threat threat;
  final VoidCallback onTap;

  const ThreatIndicator({
    super.key,
    required this.threat,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Threat.getSeverityColor(threat.severity).withOpacity(0.2),
          child: Icon(
            threat.icon,
            color: Threat.getSeverityColor(threat.severity),
          ),
        ),
        title: Row(
          children: [
            Expanded(child: Text(threat.title)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Threat.getSeverityColor(threat.severity).withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                threat.severity,
                style: TextStyle(
                  color: Threat.getSeverityColor(threat.severity),
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(threat.description),
            const SizedBox(height: 4),
            Row(
              children: [
                Text(
                  threat.timestamp,
                  style: textTheme.bodyMedium?.copyWith(fontSize: 12),
                ),
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Threat.getPaymentTypeColor(threat.paymentType).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    threat.paymentType,
                    style: TextStyle(
                      color: Threat.getPaymentTypeColor(threat.paymentType),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        onTap: onTap,
      ),
    );
  }
}
