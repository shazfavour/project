import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class SecurityBreakdownChart extends StatelessWidget {
  final List<Map<String, dynamic>> securityData;

  const SecurityBreakdownChart({
    super.key,
    required this.securityData,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 3,
          child: PieChart(
            PieChartData(
              sectionsSpace: 2,
              centerSpaceRadius: 40,
              sections: List.generate(securityData.length, (i) {
                final data = securityData[i];
                final total = securityData.fold(0, (sum, item) => sum + item['threats'] as int);
                return PieChartSectionData(
                  color: data['color'] as Color,
                  value: data['threats'] as double,
                  title: '${((data['threats'] as int) / total * 100).round()}%',
                  radius: 100,
                  titleStyle: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                );
              }),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          flex: 2,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: securityData.map((data) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 6.0),
                child: Row(
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: data['color'] as Color,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${data['type']}: ${data['threats']}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
