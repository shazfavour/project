import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'DashboardScreen.dart';
import 'ThemeProvider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => ThemeProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return MaterialApp(
      title: 'Payment Threat Intelligence',
      theme: themeProvider.currentTheme,
      debugShowCheckedModeBanner: false,
      home: const DashboardScreen(),
    );
  }
}

// lib/models/threat.dart
class Threat {
  final String id;
  final String title;
  final String description;
  final String timestamp;
  final String severity;
  final String paymentType;
  final IconData icon;
  final bool isResolved;

  Threat({
    required this.id,
    required this.title,
    required this.description,
    required this.timestamp,
    required this.severity,
    required this.paymentType,
    required this.icon,
    this.isResolved = false,
  });

  static Color getSeverityColor(String severity) {
    switch (severity.toLowerCase()) {
      case 'critical':
        return const Color(0xFFEA4335);
      case 'high':
        return const Color(0xFFF66D00);
      case 'medium':
        return const Color(0xFFFBBC05);
      case 'low':
        return const Color(0xFF34A853);
      default:
        return Colors.grey;
    }
  }

  static Color getPaymentTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'card':
        return const Color(0xFF4285F4);
      case 'mobile':
        return const Color(0xFF34A853);
      case 'crypto':
        return const Color(0xFFF66D00);
      case 'e-pay':
        return const Color(0xFF9334E6);
      default:
        return Colors.grey;
    }
  }

  String getDetailedDescription() {
    switch (title) {
      case 'Card Skimming Attack':
        return 'A sophisticated card skimming malware has been detected on several point-of-sale systems. The malware captures card data during transaction processing and exfiltrates it to remote servers. Analysis indicates the malware has been active for approximately 7 days before detection, potentially compromising customer payment card information. The attack shows signs of being part of a coordinated campaign targeting retailers in the region.';
      case 'Phishing Campaign':
        return 'An ongoing phishing campaign is targeting users of mobile payment applications. The attackers are sending convincing SMS messages and emails that mimic official communications from payment providers. These messages contain links to fraudulent websites designed to steal login credentials and financial information. The campaign is notable for its sophisticated imitation of official app interfaces and use of stolen branding assets.';
      case 'Crypto Exchange Vulnerability':
        return 'A critical vulnerability has been identified in the API implementation of multiple cryptocurrency exchanges. This vulnerability could allow attackers to bypass authentication checks and perform unauthorized transactions. Technical analysis suggests the vulnerability exists in a widely-used third-party library responsible for signature verification. There is evidence that the vulnerability is being actively exploited in targeted attacks.';
      case 'Man-in-the-Middle Attack':
        return 'A series of suspicious DNS redirects have been detected affecting users attempting to access payment gateway services. These redirects route users through malicious proxy servers that can intercept sensitive transaction data before forwarding it to legitimate payment processors. The attack leverages compromised DNS infrastructure and appears to be targeting specific geographic regions and ISPs.';
      default:
        return 'Detailed information about this threat is currently being compiled. Our security team is analyzing the attack vectors, potential impact, and recommended mitigation strategies. Updates will be provided as more information becomes available.';
    }
  }

  List<String> getRecommendedActions() {
    switch (title) {
      case 'Card Skimming Attack':
        return [
          'Immediately isolate affected POS systems from the network',
          'Deploy updated malware signatures to detection systems',
          'Scan all POS systems with advanced anti-malware tools',
          'Notify potentially affected customers according to data breach protocol',
          'Implement hardware-based point-to-point encryption for all card transactions'
        ];
      case 'Phishing Campaign':
        return [
          'Issue warning communications to all users about the phishing threat',
          'Implement additional authentication factors for high-risk transactions',
          'Deploy anti-phishing warnings in mobile app UI',
          'Add domain blocking for identified phishing sites',
          'Review and enhance educational materials on phishing recognition'
        ];
      case 'Crypto Exchange Vulnerability':
        return [
          'Temporarily disable affected API endpoints until patched',
          'Apply security patch to affected systems',
          'Reset API keys for all users',
          'Conduct thorough audit of all recent transactions',
          'Implement additional rate limiting and anomaly detection'
        ];
      case 'Man-in-the-Middle Attack':
        return [
          'Force SSL certificate revalidation for all connections',
          'Implement DNSSEC for domain infrastructure',
          'Issue advisory to users recommending connection only through secure channels',
          'Deploy decoy transactions to identify compromise patterns',
          'Enhance network traffic analysis to detect unusual routing patterns'
        ];
      default:
        return [
          'Isolate affected systems from critical infrastructure',
          'Deploy additional monitoring for related attack vectors',
          'Review and update security policies related to this threat category',
          'Conduct focused security training for relevant teams',
          'Accelerate planned security upgrades for affected components'
        ];
    }
  }
}

// lib/models/transaction.dart
class Transaction {
  final String id;
  final double amount;
  final String paymentMethod;
  final String timestamp;
  final String status;
  final String userId;
  final double riskScore;

  Transaction({
    required this.id,
    required this.amount,
    required this.paymentMethod,
    required this.timestamp,
    required this.status,
    required this.userId,
    required this.riskScore,
  });
}

// lib/models/user.dart
class User {
  final String id;
  final String name;
  final String email;
  final String role;
  final List<String> permissions;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    required this.permissions,
  });
}